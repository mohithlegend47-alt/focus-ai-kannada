# FOCUS AI Kannada — Android-only build guide

This is an offline-first Android app project. It targets Android 10 (API 29) and newer. It has no INTERNET permission, no account, no cloud AI, and no analytics SDK.

## Included features
- Kannada and English spoken motivation using Android TextToSpeech.
- Mood selection: happy, sad, stressed, focused.
- Offline motivational messages and a short story.
- Mood-based Kannada music suggestions (suggestions only; no bundled/streamed songs).
- Daily study goal saved locally.
- 25-minute focus timer and 5-minute break timer.
- Today's app usage report.
- Optional accessibility distraction reminders.
- No online server dependency for core features.

## Honest limitations
This is a rules-based offline assistant, not a full offline large language model. Kannada speech depends on the Kannada voice being installed and supported by the phone's TextToSpeech engine. The distraction coach uses selected app names and visible labels; it cannot reliably tell every YouTube lesson from every Short. It is a reminder, not a hard app or website blocker. No music files are bundled. Website blocking and a reliable AI that understands every screen would need additional carefully designed Android features and permissions.

## Build from an Android phone using GitHub (no laptop)
This project ZIP is uploaded to your phone. GitHub Actions will compile it in the cloud.

1. Download and extract this ZIP on your Android phone.
2. Open https://github.com in Chrome and sign in.
3. Create a new public or private repository named `focus-ai-kannada`.
4. Upload the extracted project files/folders into the repository root. If mobile upload cannot select folders, use GitHub's web editor to create/upload the files, or use a browser's desktop-site option. Do not upload only the ZIP if you want the included workflow to run automatically.
5. Make sure `.github/workflows/build-apk.yml` exists in the repository. It is included in this project.
6. Open the repository → Actions → **Build FOCUS AI Kannada APK** → Run workflow. A push to main also starts a build.
7. Wait for a green successful run. Open it and find the Artifacts section.
8. Download `FOCUS-AI-Kannada-debug-apk`.
9. Extract that downloaded ZIP. It contains `app-debug.apk`.
10. Tap the APK to install. If asked, allow Chrome or your file manager to install unknown apps.

## First launch
1. Open FOCUS AI.
2. Tap Kannada voice. If it cannot speak, open Android Settings → Text-to-speech output and install Kannada voice data if offered. Menu names vary by phone.
3. Enable Usage Access in Android settings and return to refresh the report.
4. Enable the FOCUS AI accessibility service in Accessibility settings if you want reminders.
5. Use the mood, goal, song suggestion, story and timer features.

## GitHub build settings
The workflow uses JDK 17, Gradle 8.9, Android Gradle Plugin 8.7.3, Kotlin 2.0.21 and Android SDK 35. The resulting APK is a debug APK for personal testing, not a Play Store release-signed APK.
