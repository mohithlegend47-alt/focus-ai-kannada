plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}
android {
    namespace = "com.focusai.kannada"
    compileSdk = 35
    defaultConfig {
        applicationId = "com.focusai.kannada"
        minSdk = 29
        targetSdk = 35
        versionCode = 3
        versionName = "3.0"
    }
}
