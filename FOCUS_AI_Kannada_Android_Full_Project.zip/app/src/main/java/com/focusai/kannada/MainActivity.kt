package com.focusai.kannada

import android.app.Activity
import android.app.AppOpsManager
import android.app.usage.UsageStatsManager
import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.os.CountDownTimer
import android.provider.Settings
import android.speech.tts.TextToSpeech
import android.view.Gravity
import android.widget.*
import java.util.Locale

class MainActivity : Activity(), TextToSpeech.OnInitListener {
    private var tts: TextToSpeech? = null
    private var ttsReady = false
    private var timer: CountDownTimer? = null
    private var remainingMs = 25 * 60 * 1000L
    private lateinit var timerLabel: TextView
    private lateinit var usageLabel: TextView
    private lateinit var messageLabel: TextView
    private lateinit var goalInput: EditText
    private var mood = "focused"
    private var language = "kn"

    private val kannada = mapOf(
        "happy" to "ಚೆನ್ನಾಗಿದೆ! ಈ ಸಂತೋಷದ ಶಕ್ತಿಯನ್ನು ನಿಮ್ಮ ಗುರಿಗಾಗಿ ಬಳಸಿ. ಈಗ ಓದಲು ಶುರುಮಾಡಿ.",
        "sad" to "ಪರವಾಗಿಲ್ಲ. ಒಂದು ಸಣ್ಣ ಹೆಜ್ಜೆಯಿಂದ ಪ್ರಾರಂಭಿಸಿ. ನೀವು ಮಾಡಬಹುದು.",
        "stressed" to "ಸ್ವಲ್ಪ ವಿರಾಮ ತೆಗೆದುಕೊಳ್ಳಿ. ನಿಧಾನವಾಗಿ ಉಸಿರಾಡಿ. ಒಂದೇ ಕೆಲಸದ ಮೇಲೆ ಗಮನ ಕೊಡಿ.",
        "focused" to "ಅದ್ಭುತ! ಮುಂದಿನ ಇಪ್ಪತ್ತೈದು ನಿಮಿಷ ನಿಮ್ಮ ಓದಿಗೆ ಮೀಸಲು."
    )
    private val english = mapOf(
        "happy" to "Great energy! Use it for your goals. Start studying now.",
        "sad" to "It's okay. Begin with one small step. You can do this.",
        "stressed" to "Take a short pause, breathe slowly, and focus on one task.",
        "focused" to "Excellent. Give the next twenty-five minutes to your studies."
    )
    private val songs = mapOf(
        "happy" to "Kannada upbeat playlist ideas: Belageddu, Singara Siriye, Jotheyali",
        "sad" to "Gentle Kannada playlist ideas: Anisuthide, Ninnindale, Minchagi Neenu",
        "stressed" to "Calm playlist ideas: instrumental Kannada melodies, flute, veena and soft acoustic tracks",
        "focused" to "Study sounds: instrumental Kannada melodies, soft piano, rain ambience"
    )

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        tts = TextToSpeech(this, this)
        val p = getSharedPreferences("focus", MODE_PRIVATE)
        mood = p.getString("mood", "focused") ?: "focused"
        language = p.getString("language", "kn") ?: "kn"
        buildScreen()
    }

    override fun onInit(status: Int) {
        if (status == TextToSpeech.SUCCESS) {
            val r = tts?.setLanguage(if (language == "kn") Locale("kn", "IN") else Locale.US)
            ttsReady = r != TextToSpeech.LANG_MISSING_DATA && r != TextToSpeech.LANG_NOT_SUPPORTED
        }
    }

    private fun buildScreen() {
        val page = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(18, 22, 18, 24)
            setBackgroundColor(0xFFF3F5FA.toInt())
        }
        page.addView(TextView(this).apply {
            text = "🤖 FOCUS AI"
            textSize = 30f
            gravity = Gravity.CENTER
            setTextColor(0xFF263B68.toInt())
        })
        page.addView(TextView(this).apply {
            text = "ನಿಮ್ಮ ವೈಯಕ್ತಿಕ ಆಫ್‌ಲೈನ್ ಅಧ್ಯಯನ ಸಹಾಯಕ"
            textSize = 15f
            gravity = Gravity.CENTER
            setPadding(0, 4, 0, 16)
        })

        page.addView(header("ಭಾಷೆ / LANGUAGE"))
        val langs = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        langs.addView(btn("ಕನ್ನಡ ಧ್ವನಿ") {
            language = "kn"; save("language", language)
            tts?.language = Locale("kn", "IN")
            speak("ನಮಸ್ಕಾರ! ಓದಲು ಸಿದ್ಧರಾಗಿ.")
        }, weight())
        langs.addView(btn("English voice") {
            language = "en"; save("language", language)
            tts?.language = Locale.US
            speak("Hello! Let's get ready to study.")
        }, weight())
        page.addView(langs)
        page.addView(btn("Install / check voice data") {
            try { startActivity(Intent(TextToSpeech.Engine.ACTION_INSTALL_TTS_DATA)) }
            catch (_: Exception) { toast("Open Android Text-to-speech settings and check Kannada voice data.") }
        })

        page.addView(header("ನಿಮ್ಮ ಮನಸ್ಥಿತಿ / YOUR MOOD"))
        val moods = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        listOf("😊" to "happy", "😔" to "sad", "😣" to "stressed", "🎯" to "focused").forEach { (e, m) ->
            moods.addView(btn(e) { mood = m; save("mood", m); showMood() }, weight())
        }
        page.addView(moods)
        messageLabel = TextView(this).apply {
            textSize = 15f; setTextColor(0xFF263238.toInt()); setPadding(12, 12, 12, 12)
        }
        page.addView(messageLabel)
        page.addView(btn("Speak motivation / ಪ್ರೇರಣೆ ಹೇಳು") { speak(message()) })

        page.addView(header("MOOD-BASED KANNADA MUSIC IDEAS"))
        page.addView(btn("Suggest songs for my mood") {
            val suggestion = songs[mood] ?: songs["focused"]!!
            toast(suggestion)
            speak(if (language == "kn") "ನಿಮ್ಮ ಮನಸ್ಥಿತಿಗೆ ಸಂಗೀತದ ಸಲಹೆ ಸಿದ್ಧವಾಗಿದೆ." else "Here are music ideas for your mood.")
        })
        page.addView(TextView(this).apply {
            text = "Note: This suggests music only. It does not stream or include copyrighted songs. Play music you already own on your phone."
            textSize = 12f; setPadding(8, 4, 8, 8)
        })

        page.addView(header("YOUR DAILY STUDY GOAL"))
        goalInput = EditText(this).apply {
            hint = "ಉದಾ: Finish Chemistry revision"
            setText(getSharedPreferences("focus", MODE_PRIVATE).getString("goal", ""))
        }
        page.addView(goalInput)
        page.addView(btn("Save today's goal") {
            save("goal", goalInput.text.toString())
            toast("Today's goal saved on this phone.")
        })
        page.addView(btn("Offline motivational story") { showStory() })

        page.addView(header("POMODORO STUDY TIMER"))
        timerLabel = TextView(this).apply {
            textSize = 38f; gravity = Gravity.CENTER
            setTextColor(0xFF263B68.toInt()); setPadding(0, 8, 0, 8)
        }
        page.addView(timerLabel)
        val timerRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        timerRow.addView(btn("Start 25 min") { startTimer() }, weight())
        timerRow.addView(btn("Pause") { timer?.cancel(); timer = null }, weight())
        timerRow.addView(btn("Reset") {
            timer?.cancel(); timer = null; remainingMs = 25*60*1000L; updateTimer()
        }, weight())
        page.addView(timerRow)
        page.addView(btn("Start 5-minute break") {
            timer?.cancel(); timer = null; remainingMs = 5*60*1000L; updateTimer(); startTimer()
        })

        page.addView(header("TODAY'S SCREEN-TIME REPORT"))
        page.addView(btn("Enable usage access") { startActivity(Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS)) })
        page.addView(btn("Refresh today's report") { refreshUsage() })
        usageLabel = TextView(this).apply {
            text = "Enable Usage Access to see app usage."; textSize = 14f
            setPadding(10, 12, 10, 12); setTextColor(0xFF263238.toInt())
        }
        page.addView(usageLabel)

        page.addView(header("DISTRACTION COACH"))
        page.addView(TextView(this).apply {
            text = "Optional gentle reminders when selected social/video apps or feed-like labels are noticed. Reminders are dismissible."
            textSize = 14f; setPadding(8, 4, 8, 8)
        })
        page.addView(btn("Open accessibility settings") { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) })
        page.addView(btn("Turn distraction reminders ON/OFF") {
            val p = getSharedPreferences("focus", MODE_PRIVATE)
            val v = !p.getBoolean("coach_enabled", true)
            p.edit().putBoolean("coach_enabled", v).apply()
            toast(if (v) "Reminders enabled" else "Reminders disabled")
        })

        page.addView(header("PRIVACY & OFFLINE MODE"))
        page.addView(TextView(this).apply {
            text = "No account, cloud AI, internet permission or analytics. Your mood, goal and messages stay on this phone. Usage and accessibility access are optional and can be disabled in Android Settings."
            textSize = 13f; setPadding(8, 4, 8, 12)
        })
        val scroll = ScrollView(this)
        scroll.addView(page)
        setContentView(scroll)
        showMood(); updateTimer()
    }

    private fun header(s: String) = TextView(this).apply {
        text = s; textSize = 13f; setTextColor(0xFF52658D.toInt())
        setPadding(4, 18, 4, 6)
    }
    private fun weight() = LinearLayout.LayoutParams(0, -2, 1f)
    private fun btn(label: String, action: () -> Unit) = Button(this).apply {
        text = label; isAllCaps = false; textSize = 13f
        setOnClickListener { action() }
    }
    private fun save(k: String, v: String) { getSharedPreferences("focus", MODE_PRIVATE).edit().putString(k, v).apply() }
    private fun message() = if (language == "kn") kannada[mood] ?: kannada["focused"]!! else english[mood] ?: english["focused"]!!
    private fun showMood() { messageLabel.text = message() }
    private fun speak(s: String) {
        if (ttsReady) {
            tts?.setLanguage(if (language == "kn") Locale("kn", "IN") else Locale.US)
            tts?.speak(s, TextToSpeech.QUEUE_FLUSH, null, "focus-ai-message")
        } else toast("Kannada voice data may be unavailable. Install it in Android Text-to-speech settings.")
    }
    private fun showStory() {
        val story = if (language == "kn")
            "ಒಬ್ಬ ವಿದ್ಯಾರ್ಥಿ ಪ್ರತಿದಿನ ಸ್ವಲ್ಪ ಸಮಯ ಓದುತ್ತಿದ್ದ. ಆರಂಭದಲ್ಲಿ ಅವನಿಗೆ ಕಷ್ಟವಾಯಿತು. ಆದರೆ ಪ್ರತಿದಿನ ಒಂದು ಸಣ್ಣ ಗುರಿ ಮುಗಿಸುತ್ತಾ ಹೋದ. ಕೆಲವು ವಾರಗಳ ನಂತರ ಅವನಿಗೆ ಆತ್ಮವಿಶ್ವಾಸ ಹೆಚ್ಚಾಯಿತು. ದೊಡ್ಡ ಯಶಸ್ಸು ಒಂದು ಸಣ್ಣ ಹೆಜ್ಜೆಯಿಂದ ಆರಂಭವಾಗುತ್ತದೆ."
        else
            "A student decided to study a little every day. At first it felt difficult, but the student completed one small goal at a time. After a few weeks, confidence grew. Big progress begins with one small step."
        toast(story); speak(story)
    }
    private fun startTimer() {
        if (timer != null) return
        timer = object : CountDownTimer(remainingMs, 1000) {
            override fun onTick(ms: Long) { remainingMs = ms; updateTimer() }
            override fun onFinish() {
                remainingMs = 5*60*1000L; timer = null; updateTimer()
                val s = if (language == "kn") "ಅಭಿನಂದನೆಗಳು! ಓದುವ ಸಮಯ ಮುಗಿದಿದೆ. ಐದು ನಿಮಿಷ ವಿರಾಮ ತೆಗೆದುಕೊಳ್ಳಿ." else "Well done! Study time is complete. Take a five-minute break."
                speak(s); toast(s)
            }
        }.start()
    }
    private fun updateTimer() {
        val s = remainingMs / 1000
        timerLabel.text = String.format(Locale.US, "%02d:%02d", s/60, s%60)
    }
    private fun refreshUsage() {
        val ops = getSystemService(Context.APP_OPS_SERVICE) as AppOpsManager
        if (ops.checkOpNoThrow("android:get_usage_stats", android.os.Process.myUid(), packageName) != AppOpsManager.MODE_ALLOWED) {
            usageLabel.text = "Usage access is off. Enable it above, then refresh."; return
        }
        val usm = getSystemService(Context.USAGE_STATS_SERVICE) as UsageStatsManager
        val c = java.util.Calendar.getInstance().apply {
            set(java.util.Calendar.HOUR_OF_DAY,0); set(java.util.Calendar.MINUTE,0)
            set(java.util.Calendar.SECOND,0); set(java.util.Calendar.MILLISECOND,0)
        }
        val items = usm.queryUsageStats(UsageStatsManager.INTERVAL_DAILY, c.timeInMillis, System.currentTimeMillis())
            .filter { it.totalTimeInForeground > 0 }.sortedByDescending { it.totalTimeInForeground }.take(15)
        usageLabel.text = if (items.isEmpty()) "No usage data yet." else items.joinToString("\n") {
            val n = try { packageManager.getApplicationLabel(packageManager.getApplicationInfo(it.packageName,0)).toString() }
                    catch (_: Exception) { it.packageName }
            val m = it.totalTimeInForeground / 60000
            "$n — ${m/60}h ${m%60}m"
        }
    }
    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_LONG).show()
    override fun onDestroy() {
        timer?.cancel(); tts?.stop(); tts?.shutdown(); super.onDestroy()
    }
}
