package com.focusai.kannada

import android.accessibilityservice.AccessibilityService
import android.graphics.PixelFormat
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView

class FocusAccessibilityService : AccessibilityService() {
    private val handler = Handler(Looper.getMainLooper())
    private var lastNudge = 0L
    private var overlay: android.view.View? = null
    private var wm: WindowManager? = null
    private val socialVideoApps = setOf(
        "com.google.android.youtube", "com.instagram.android",
        "com.zhiliaoapp.musically", "com.facebook.katana",
        "com.facebook.lite", "com.reddit.frontpage"
    )
    private val feedLabels = listOf("shorts", "reels", "for you", "trending", "recommended")

    override fun onServiceConnected() { wm = getSystemService(WINDOW_SERVICE) as WindowManager }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        if (event == null) return
        val pkg = event.packageName?.toString() ?: return
        if (pkg == packageName || pkg.startsWith("com.android.")) return
        if (!getSharedPreferences("focus", MODE_PRIVATE).getBoolean("coach_enabled", true)) return
        val visible = readLabels(rootInActiveWindow).lowercase()
        val detected = pkg in socialVideoApps || feedLabels.any { visible.contains(it) }
        val now = System.currentTimeMillis()
        if (detected && now - lastNudge > 180_000) {
            lastNudge = now
            handler.post { showReminder() }
        }
    }

    private fun readLabels(node: AccessibilityNodeInfo?, depth: Int = 0): String {
        if (node == null || depth > 10) return ""
        val out = StringBuilder()
        node.text?.let { out.append(it).append(' ') }
        node.contentDescription?.let { out.append(it).append(' ') }
        for (i in 0 until node.childCount.coerceAtMost(30)) out.append(readLabels(node.getChild(i), depth + 1))
        return out.toString()
    }

    private fun showReminder() {
        if (overlay != null) return
        val kn = getSharedPreferences("focus", MODE_PRIVATE).getString("language", "kn") == "kn"
        val panel = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; setPadding(26,22,26,22)
            setBackgroundColor(0xFF1E3159.toInt())
        }
        panel.addView(TextView(this).apply {
            text = "🤖 FOCUS AI"; textSize = 23f; setTextColor(0xFFFFFFFF.toInt())
        })
        panel.addView(TextView(this).apply {
            text = if (kn) "ಸ್ವಲ್ಪ ಗಮನಿಸಿ! ಈ ಸಮಯ ನಿಮ್ಮ ಗುರಿಗೆ ಸಹಾಯ ಮಾಡುತ್ತಿದೆಯೇ? ಈಗ ಓದಿಗೆ ಹಿಂತಿರುಗೋಣ." else "Quick check: is this helping your goal? Let's return to studying."
            textSize = 16f; setTextColor(0xFFFFFFFF.toInt()); setPadding(0,12,0,12)
        })
        panel.addView(Button(this).apply {
            text = if (kn) "ಓದಿಗೆ ಹಿಂತಿರುಗಿ" else "Back to studying"
            setOnClickListener { removeReminder(); performGlobalAction(GLOBAL_ACTION_HOME) }
        })
        panel.addView(Button(this).apply {
            text = if (kn) "ಈಗ ಬೇಡ" else "Dismiss"
            setOnClickListener { removeReminder() }
        })
        val lp = WindowManager.LayoutParams(
            (resources.displayMetrics.widthPixels * .88).toInt(),
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.CENTER }
        try { wm?.addView(panel, lp); overlay = panel } catch (_: Exception) {}
    }
    private fun removeReminder() {
        try { overlay?.let { wm?.removeView(it) } } catch (_: Exception) {}
        overlay = null
    }
    override fun onInterrupt() { removeReminder() }
    override fun onDestroy() { removeReminder(); super.onDestroy() }
}
